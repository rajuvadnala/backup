﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using StockService.Model;
using StockService.Services;

namespace OCO
{
    internal class HostBuilder
    {
        public static IHost BuildHost(string[] args)
        {
            HostApplicationBuilder builder = Microsoft.Extensions.Hosting.Host.CreateApplicationBuilder(args);

            builder.Configuration.AddJsonFile($"appsettings.json", true, true);
            // Add services to the container.
            builder.Services.Configure<Config>(builder.Configuration.GetSection("Config"));
           // builder.Services.AddScoped<INseService, NseService>();
           // builder.Services.AddScoped<IBseService, BseService>();
           // builder.Services.AddScoped<IConsolidateAlertService, ConsolidateAlertService>();
            builder.Services.AddScoped<IKiteService, KiteService>();
            builder.Services.AddScoped<ISoundService, SoundService>();
            builder.Services.AddScoped<IHttpService, HttpService>();
            //builder.Services.AddScoped<IAutoOrderService, AutoOrderService>();
            builder.Services.AddScoped<IFileService, FileService>();
            builder.Services.AddHttpClient();

            return builder.Build();
        }
    }
}
