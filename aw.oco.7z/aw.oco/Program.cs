﻿
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using OCO;
using StockService.Model;
using StockService.Services;

var app = HostBuilder.BuildHost(args);

var fileService = app.Services.GetRequiredService<IFileService>();
var kiteService = app.Services.GetRequiredService<IKiteService>();
var soundService = app.Services.GetRequiredService<ISoundService>();

while (true)
{
    foreach (var queue in fileService.GetOCOQueue())
    {
        Console.WriteLine($"{DateTime.Now.ToLongTimeString()}: Found OCO for {queue.StockCode}");
        fileService.DeleteFromOCOQueue(queue.FileName);
        //process asyncronously
        await TryProcessOCO(queue);
    }
    //Console.Write(".");
    await Task.Delay(500);
}

async Task TryProcessOCO(OCORequest request)
{
    try
    {
        while (true)
        {
            Console.WriteLine($"{DateTime.Now.ToLongTimeString()}: Processing OCO for {request.StockCode}");
            if (await ProcessOCO(request))
            {
                Console.WriteLine($"{DateTime.Now.ToLongTimeString()}: Processing OCO completed for {request.StockCode}");
                soundService.PlaySound(AlertTypes.OCO_SUCCESS);
                break;
            }

            await Task.Delay(300);
        }
    }
    catch(Exception ex)
    {
        Console.WriteLine($"{DateTime.Now.ToLongTimeString()}: Unable to process OCO for {request.StockCode} | ex: "+ex.Message);
    }
    
}

async Task<bool> ProcessOCO(OCORequest request)
{
    kiteService.SetToken(request.KiteToken);
    var targetStatus = await kiteService.GetOrderStatus(request.TargetOrderId);
    var slStatus = await kiteService.GetOrderStatus(request.StopLossOrderId);

    if (targetStatus.IsOrderComplete && slStatus.IsOrderComplete)
    {
        return true;
    }

    if (targetStatus.IsOrderComplete && !slStatus.IsOrderComplete) {
        //Cancel Stoploss
        await CancelOrder(request.StopLossOrderId);
        return true;
    }

    if (slStatus.IsOrderComplete && !targetStatus.IsOrderComplete) {
        //Cancel target
        await CancelOrder(request.TargetOrderId);
        return true;
    }
    return false;
}

async Task CancelOrder(string orderId)
{
    OrderCancelResponse orderCancelResponse = await kiteService.CancelOrder(orderId);
    if (orderCancelResponse.IsSuccess)
    {
        Console.WriteLine($"{orderId} successfully cancelled");
    }
    else
    {
        Console.WriteLine($"{orderId} unable to cancel; err {orderCancelResponse.ErrorMsg}");
    }
}
