using aw_web.Components;
using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.Firestore;
using Microsoft.AspNetCore.Builder.Extensions;
using Microsoft.Extensions.Configuration;
using StockService.Model;
using StockService.Repository;
using StockService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Configuration.AddJsonFile("appsettings.json");

// Add services to the container.
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.Configure<Config>(builder.Configuration.GetSection("Config"));
builder.Services.AddScoped<INseService, NseService>();
builder.Services.AddScoped<IBseService, BseService>();
builder.Services.AddScoped<IConsolidateAlertService, ConsolidateAlertService>();
builder.Services.AddScoped<IKiteService, KiteService>();
builder.Services.AddScoped<IMatchService, MatchService>();
builder.Services.AddScoped<IHttpService, HttpService>();
builder.Services.AddScoped<IAutoOrderService, AutoOrderService>();
builder.Services.AddScoped<IFileService, FileService>();
builder.Services.AddScoped<IAlertRepository, AlertRepository>();
//builder.Services.AddSingleton(() => new HttpClient(
//    new SocketsHttpHandler { PooledConnectionLifetime = TimeSpan.FromMinutes(2) }
//));

builder.Services.AddHttpClient();

//Firebase setup
var credentialPath = Path.Combine(Directory.GetCurrentDirectory(), "serviceAccountKey.json");
Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", credentialPath);

// Initialize Firebase Admin SDK
FirebaseApp.Create(new AppOptions()
{
    Credential = GoogleCredential.GetApplicationDefault()
});

var projectId = builder.Configuration.GetValue<string>("Config:FirebaseConfig:ProjectId");
// Add Firestore DB Service (use Project ID)
builder.Services.AddSingleton(FirestoreDb.Create(projectId));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>().AddInteractiveServerRenderMode();

app.Run();
